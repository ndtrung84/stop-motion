# How to Build & Install the Stop Motion Studio Android `.apk`

Because the cloud preview sandbox does not include the 4 GB Android SDK binary compiler (`aapt2` / `android.jar`), this package contains your **complete, pre-configured Android APK project** with camera permissions (`android.permission.CAMERA`), WebRTC live camera bridge, custom app icons, and offline assets already wired up.

Choose whichever of the **3 easy methods** below you prefer to generate your `.apk` file:

## Option 1: Zero-Code Cloud Build via GitHub Actions (No installs needed on your PC/Phone)
1. Create a free repository on GitHub and upload the contents of this ZIP folder.
2. Click the **Actions** tab in your GitHub repository and run the **Build Android APK** workflow (`.github/workflows/build-apk.yml` is already included!).
3. In ~2 minutes, download **`StopMotionStudio-debug-apk`** (`app-debug.apk`) from the workflow Artifacts and tap it on your Android phone to install!

## Option 2: Build Locally in Android Studio (or Command Line)
1. Open the **`android/`** folder inside **Android Studio**.
2. Wait a moment for Gradle sync to finish, then click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Your installable APK will be saved at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
   *(Or from a terminal with Gradle installed, run `cd android && gradle assembleDebug`).*

## Option 3: Instant Online Web-to-APK Packager (WebIntoApp / VoltBuilder / PWABuilder)
- The **`www/`** folder contains the standalone `index.html`, `manifest.json`, `sw.js`, and 192px/512px app icons.
- You can upload `www/index.html` (or the `www/` zip) directly to an online HTML-to-APK builder such as **WebIntoApp.com** or **VoltBuilder**, enable **Camera Permission**, and download the signed `.apk` in under 60 seconds.
